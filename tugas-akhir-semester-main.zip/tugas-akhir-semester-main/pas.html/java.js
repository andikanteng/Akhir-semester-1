
const emailInput = document.getElementById('email');
const button = document.getElementById('button');
button.addEventListener('click', function() {
    emailInput.value = '';
});
document.getElementById("button").addEventListenert("click", function(){
window.open("profil.html", "_blank")
})





